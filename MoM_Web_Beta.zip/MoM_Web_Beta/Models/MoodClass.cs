﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MoM_Web_Beta.Models
{
    public class MoodClass
    {

        public int Mood_id { get; set; }
        public string time { get; set; }
        public DateTime date { get; set; }
        public string emotion { get; set; }

        public int student_Num { get; set; }
    }
}