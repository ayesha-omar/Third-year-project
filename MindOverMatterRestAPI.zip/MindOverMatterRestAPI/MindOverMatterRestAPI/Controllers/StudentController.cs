﻿using HashPass;
using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class StudentController : ApiController
    {

        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/Student/EditStudent")]
        [HttpPost]
        public IHttpActionResult EditStudent(StudentClass studentClass)
        {
            if (studentClass==null) {
                return Ok(false);
            }
            var student = (from s in db.Students
                           where s.Student_num.Equals(studentClass.studentNumber)
                           select s).FirstOrDefault();

            student.Stu_name = studentClass.Name.Trim();
            student.Stu_surname = studentClass.Surname.Trim();
            student.Stu_email = studentClass.email.Trim();

            try
            {
                db.SubmitChanges(); //does not want to update
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();

                return Ok(false);
            }

        }

        [Route("api/Student/getStudent")]
        [HttpGet]
        public IHttpActionResult GetStudent(int Studentnum)
        {
            var student = (from a in db.Students
                           where a.Student_num.Equals(Studentnum)
                           select a).FirstOrDefault();

            if (student==null) {
                return Ok(false);
            }
            StudentClass studentClass = new StudentClass { studentNumber = student.Student_num, Name = student.Stu_name, Surname = student.Stu_surname, email = student.Stu_email,gender=Convert.ToChar(student.Stu_gender), DOB=Convert.ToString(student.Stu_dob),Qualification=student.Stu_qualif};

            return Ok(studentClass);
        }

        [Route("api/Student/GetStudents")]
        [HttpGet]
        public IHttpActionResult GetStudents()
        {
            List<StudentClass> students = new List<StudentClass>();
            var list = (from a in db.Students
                        select a);

            if (list==null) {
                return Ok(false);
            }

            foreach (var student in list)
            {
                StudentClass studentClass = new StudentClass { studentNumber = student.Student_num, Name = student.Stu_name, Surname = student.Stu_surname, email = student.Stu_email, gender = Convert.ToChar(student.Stu_gender), DOB = Convert.ToString(student.Stu_dob), Qualification = student.Stu_qualif };

                students.Add(studentClass);
            }

            return Ok(students);
        }


        [Route("api/Student/AddStudent")]
        [HttpPost]
        public IHttpActionResult AddStudent(StudentClass studentClass)
        {
            if (studentClass==null) {
                return Ok(false);
            }

            Student student = new Student
            {
                Stu_name=studentClass.Name,
                Stu_surname=studentClass.Surname,
                Stu_email=studentClass.email,
                Stu_password= Secrecy.HashPassword(studentClass.password),
                Stu_gender=studentClass.gender,
                Stu_dob= Convert.ToDateTime(studentClass.DOB),
                Stu_qualif=studentClass.Qualification
            };

            db.Students.InsertOnSubmit(student);

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException e) 
            {
                e.GetBaseException();
                return Ok(false);
            }

        }
    }
}
