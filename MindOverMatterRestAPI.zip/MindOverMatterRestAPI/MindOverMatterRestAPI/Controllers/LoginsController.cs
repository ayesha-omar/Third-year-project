﻿using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class LoginsController : ApiController
    {

        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/Login/loginStudent")]
        [HttpGet]
        public IHttpActionResult loginStudent(string useremail, string password)
        {

            //select student from database
            var student = (from a in db.Students
                           where a.Stu_email.Equals(useremail)
                           && a.Stu_password.Equals(password)
                           select a).FirstOrDefault();

            if (student == null) {
                return Ok(false);
            }
            StudentClass studentClass = new StudentClass {studentNumber=student.Student_num,Name=student.Stu_name,Surname=student.Stu_surname,email=student.Stu_email};
            //return student
            return Ok(studentClass);


        }


        [Route("api/Login/loginUser")]
        [HttpGet]
        public IHttpActionResult loginUser(string username, string password)
        {

            User loggeduser = null;

            //user is not in Students list, check counsellor list
            var findCouns = loginCounsellor(username, password);
            if (findCouns != null)
            {
                loggeduser = new User { UserId = findCouns.Couns_id, Name = findCouns.Couns_name, surname = findCouns.Couns_Surname, email = findCouns.Couns_email, userType = "Counsellor" };
                return Ok(loggeduser);
            }
            //user is not in Counsellor list, check Admin list
            var findAdmin = loginAdmin(username, password);
            if (findAdmin != null)
            {
                loggeduser = new User { UserId = findAdmin.Admin_id, Name = findAdmin.Admin_Name, surname = findAdmin.Admin_surname, email = findAdmin.Admin_email, userType = "Admin" };
                return Ok(loggeduser);
            }

            //user not Found
            return loginStudent(username, password); //Login student or return false
        }


        //HELPER FUNCTION
        private Counsellor loginCounsellor(string username, string password)
        {
            //select counsellor from database
            var couns = (from a in db.Counsellors
                         where a.Couns_email.Equals(username)
                         && a.Couns_password.Equals(password)
                         select a).FirstOrDefault();

            //return counsellor id
            if (couns != null)
            {
                return couns;
            }
            else
            {
                return null;
            }
        }

       //HELPER FUNCTION
        private Admin loginAdmin(string username, string password)
        {
            //select Admin from database
            var admin = (from a in db.Admins
                         where a.Admin_email.Equals(username)
                         && a.Admin_password.Equals(password)
                         select a).FirstOrDefault();

            //return Admin id
            if (admin != null)
            {
                return admin;
            }
            else
            {
                return null;
            }
        }

    }
}
