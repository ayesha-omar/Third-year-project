﻿using MoM_Web_Beta.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class Prescribe : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void btnSave_Click(object sender, EventArgs e)
        {
            int studentID = Convert.ToInt32(Request.QueryString["StudentNum"]);
            int counsID = Convert.ToInt32(Session["UserID"]);
            DateTime date = DateTime.Today;
            bool prescribed = false;
            var prescribedExercises = client.getAllPrescribedExercises();
            int numExercises = 0;
            //save prescribed exercises
            if (ex1.Checked == true)
            {
                if (isExercisePrescribed(1,counsID,studentID, prescribedExercises) == false)
                {
                    prescribed = client.prescribeExercise(counsID, studentID, 1, date.Date);
                    numExercises++;
                }
                else {
                    prescribed = true; //if there is a duplicate just set to true and do not prescribe
                }
            }
            if (ex2.Checked == true)
            {
                if (isExercisePrescribed(2, counsID, studentID, prescribedExercises) == false)
                {
                    prescribed = client.prescribeExercise(counsID, studentID, 2, date.Date);
                    numExercises++;
                }

                else
                {
                    prescribed = true; //if there is a duplicate just set to true and do not prescribe
                }
            }
            if (ex3.Checked == true)
            {
                if (isExercisePrescribed(3, counsID, studentID, prescribedExercises) == false)
                {
                    prescribed = client.prescribeExercise(counsID, studentID, 3, date.Date);
                    numExercises++;
                }

                else
                {
                    prescribed = true; //if there is a duplicate just set to true and do not prescribe
                }
            }
            if (ex4.Checked == true)
            {
                if (isExercisePrescribed(4, counsID, studentID, prescribedExercises) == false)
                {
                    prescribed = client.prescribeExercise(counsID, studentID, 4, date.Date);
                    numExercises++;
                }
                else
                {
                    prescribed = true; //if there is a duplicate just set to true and do not prescribe
                }
            }
            if (ex5.Checked == true)
            {
                if (isExercisePrescribed(5, counsID, studentID, prescribedExercises) == false)
                {
                    prescribed = client.prescribeExercise(counsID, studentID, 5, date.Date);
                    numExercises++;
                }
                else
                {
                    prescribed = true; //if there is a duplicate just set to true and do not prescribe
                }
            }
            if (prescribed == true)
            {
                //set the notification for the appropriate student
                if (numExercises == 1)
                {
                    client.AddNotification(Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Request.QueryString["StudentNum"]), "You have " + numExercises + " new Prescribed Exercise.");

                }
                else {
                    client.AddNotification(Convert.ToInt32(Session["UserID"]), Convert.ToInt32(Request.QueryString["StudentNum"]), "You have " + numExercises + " new Prescribed Exercises.");

                }
                Response.Redirect("Profile.aspx?StudentNum=" + studentID);
            }


        }

        public bool isExercisePrescribed(int exID,int counsID,int studentNum,List<PrescribeExerciseClass> prescribeExerciseClasses) 
        {
            foreach (var a in prescribeExerciseClasses) {
                if (a.Ex_id.Equals(exID)&&
                    a.isPrescribed.Equals(1)
                    && a.Couns_id.Equals(counsID)
                    && a.Student_Num.Equals(studentNum)
                    ) {
                    return true;
                }
            }

            return false;
        }
    }
}