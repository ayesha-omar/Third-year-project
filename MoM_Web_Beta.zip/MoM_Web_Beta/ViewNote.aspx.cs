﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class ViewNote : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserType"].ToString().Equals("Counsellor"))
            {
                    
                String innerhtml = "";

                var note = client.GetSessionNote(Convert.ToInt32(Request.QueryString["SessId"]));
                if (note == null)
                {
                    //if student is null do not redirect
                    return;
                }

                /*if (Request.QueryString["StudentNum"] != null)
                {
                    var studentnum = Convert.ToInt32(Request.QueryString["StudentNum"]); //get student number
                    var student = client.GetStudent(studentnum);
                    //sessionNoteInformation
                    titleinfo.InnerText = "Session Notes for " + student.Name + " " + student.Surname + " on " + DateTime.Now.ToString().Substring(0, 10);
                }*/

                innerhtml += "<h2 class='txt1' style='color:black; background-color:#7abd9a'>Session Notes for StudentName on " + note.date.ToString().Substring(0, 10) + "</h2>";
                innerhtml += "<textarea readonly>" + note.description + "</textarea>";

                viewNote.InnerHtml = innerhtml;
            }
        }
    }
}