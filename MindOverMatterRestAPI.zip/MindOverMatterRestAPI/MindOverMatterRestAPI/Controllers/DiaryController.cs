﻿using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class DiaryController : ApiController
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/Diary/GetDiaryEntries")]
        [HttpGet]
        public IHttpActionResult GetDiaryEntries()
        {
            List<DiaryClass> diaries = new List<DiaryClass>();
            List<Diary> list = new List<Diary>(from a in db.Diaries
                                               select a);
            var listarray = list.ToArray<Diary>();
            //Sort the diaries to start with the recent added diary
            for (int i = listarray.Length - 1; i >= 0; i--)
            {
                DiaryClass diary = new DiaryClass { Diary_id = listarray[i].Diary_id, title = listarray[i].Diary_title, date = Convert.ToDateTime(listarray[i].Diary_date),diaryFlaggedWords= listarray[i].flaggedWords, description = listarray[i].Diary_description,isFlagged = Convert.ToInt32(listarray[i].isFlagged), student_Num = Convert.ToInt32(listarray[i].Student_num) };
                diaries.Add(diary);
            }

            return Ok(diaries);
        }

        [Route("api/Diary/GetStudentDiaryEntries")]
        [HttpGet]
        public IHttpActionResult GetStudentDiaryEntries(int studentnum)
        {
            List<DiaryClass> diaries = new List<DiaryClass>();
            List<Diary> list =new List<Diary>(from a in db.Diaries
                        where a.Student_num.Equals(studentnum)
                        select a);
            var listarray = list.ToArray<Diary>();
            //Sort the diaries to start with the recent added diary
            for (int i=listarray.Length-1;i>=0;i--)
            {
                DiaryClass diary = new DiaryClass { Diary_id = listarray[i].Diary_id, title = listarray[i].Diary_title, date = Convert.ToDateTime(listarray[i].Diary_date), diaryFlaggedWords = listarray[i].flaggedWords, description = listarray[i].Diary_description, isFlagged = Convert.ToInt32(listarray[i].isFlagged), student_Num = Convert.ToInt32(listarray[i].Student_num) };
                diaries.Add(diary);
            }

            return Ok(diaries);
        }

        //Save the diary entry to the database
        [Route("api/Diary/LogDiaryEntry")]
        [HttpPost]
        public IHttpActionResult logDiaryEntry(DiaryClass diaryClass)
        {

            if (diaryClass == null) {
                return Ok(false);
            }

            //determine whether the entry is flagged or not
            string wordsflagged = HelperClass.DetermineFlag(diaryClass.description);
            int isflagged = 0;
            if (!wordsflagged.ToUpper().Equals("NONE"))
            {
                //if it has flagged words, then mark as flagged
                isflagged = 1;
            }
            else
            {
                isflagged = 0;
            }
            var diary = new Diary
            {
                Diary_title = diaryClass.title,
                Student_num = diaryClass.student_Num,
                Diary_description = diaryClass.description,
                flaggedWords =wordsflagged, //get flagged words
                isFlagged= isflagged,
                Diary_date = diaryClass.date,
            };

            db.Diaries.InsertOnSubmit(diary);
            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (Exception ex)
            {
                ex.GetBaseException();

                return Ok(false);
            }
        }

        [Route("api/Diary/getDiaryEntry")]
        [HttpGet]
        public IHttpActionResult getDiaryEntry(int id)
        {
            //get the specified diary
            var diary = (from a in db.Diaries
                         where a.Diary_id.Equals(id)
                         select a).FirstOrDefault();
            if (diary==null) {
                return Ok(false);
            }

            DiaryClass diaryClass = new DiaryClass { Diary_id = diary.Diary_id, title = diary.Diary_title, date = Convert.ToDateTime(diary.Diary_date), diaryFlaggedWords = diary.flaggedWords, description = diary.Diary_description, isFlagged = Convert.ToInt32(diary.isFlagged), student_Num = Convert.ToInt32(diary.Student_num) };

            return Ok(diaryClass); 
        }

        [Route("api/Diary/EditDiaryEntry")]
        [HttpPost]
        public IHttpActionResult EditDiaryEntry(DiaryClass diaryClass)
        {
            //request diary with given id
            var diary = (from a in db.Diaries
                         where a.Diary_id.Equals(diaryClass.Diary_id)
                         select a).FirstOrDefault();

            //change diary fields
            diary.Diary_title = diaryClass.title.Trim();
            diary.Diary_description = diaryClass.description.Trim();
            diary.flaggedWords = HelperClass.DetermineFlag(diaryClass.description); //get flagged words
            if(!diary.flaggedWords.ToUpper().Equals("NONE")) {
                //if it has flagged words, then mark as flagged
                diary.isFlagged = 1;
            }
            else {
                diary.isFlagged = 0;
            }
            //NOTE the flagged field is just  a helper field that will help with the display on the WEB app
            try
            {
                //save changes
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();
                return Ok(false);
            }
        }


        [Route("api/Diary/FlagDiaryEntry")]
        [HttpGet]
        public IHttpActionResult FlagDiaryEntry(int diaryID)
        {
            //request diary with given id
            var diary = (from a in db.Diaries
                         where a.Diary_id.Equals(diaryID)
                         select a).FirstOrDefault();

            //change diary fields
            diary.isFlagged = 1; //set to 1 if diary is being flagged, -1 if it was once flagged, and 0 if entry was never flagged

            try
            {
                //save changes
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();
                return Ok(false);
            }
        } 
        
        [Route("api/Diary/RemoveFlagDiaryEntry")]
        [HttpGet]
        public IHttpActionResult RemoveFlagDiaryEntry(int diaryID)
        {
            //request diary with given id
            var diary = (from a in db.Diaries
                         where a.Diary_id.Equals(diaryID)
                         select a).FirstOrDefault();

            //change diary fields
            diary.isFlagged = -1; //set to 1 if diary is being flagged, -1 if it was once flagged, and 0 if entry was never flagged

            try
            {
                //save changes
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();
                return Ok(false);
            }
        }

    }
}
