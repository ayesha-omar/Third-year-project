﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class MoM : System.Web.UI.MasterPage
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserType"] != null)
            {
                //login.Visible = false;
                logout.Visible = true;
                //mynavbar.Visible = true;
                if (Session["UserType"].ToString().Equals("Student"))
                {
                }
                else if (Session["UserType"].ToString().Equals("Counsellor"))
                {
                    studenttable.Visible = true;
                    cal.Visible = true;
                    String innerhtml = "";

                    //int userid = Convert.ToInt32(Session["UserID"]);
                    //var user = client.GetCounsellor(userid);

                     innerhtml += "<tr>";
                    var couns = client.GetCounsellor(Convert.ToInt32(Session["UserID"]));
                    if (couns.isActive.Equals('0'))
                    {
                        innerhtml += "<p style='color:red'>" + Session["Username"] + "*</p>";
                    }
                    else {
                        innerhtml += "<p>" + Session["Username"] + "</p>";
                    }

                    navbarDropdown.InnerHtml = innerhtml;
                }
                else if (Session["UserType"].ToString().Equals("Admin"))
                {
                    String innerhtml = "";

                    innerhtml += "<tr>";
                    innerhtml += "<p>" + Session["Username"] + "</p>";

                    navbarDropdown.InnerHtml = innerhtml;

                    counsellortable.Visible = true;
                    exercisetable.Visible = true;
                    dashboard.Visible = true;
                    studenttable.Visible = false;
                    cal.Visible = false;
                }
                else
                {

                }

            }
        }
    }
}