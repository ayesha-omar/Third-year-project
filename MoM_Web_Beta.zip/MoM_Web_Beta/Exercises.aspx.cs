﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class Exercises : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserType"].ToString().Equals("Admin"))
            {
                String innerhtml = "";
                var users = client.GetExercises();

                foreach (var a in users)
                {
                    innerhtml += "<tr>";
                    innerhtml += "<td>" + a.Name + "</td>";
                    innerhtml += "<td>" + a.description + "</td>";
                    innerhtml += "<td>" + a.mediaPath + "</td>";
                    //innerhtml += "<td><label id='toggleActive' class='switch'><input type='checkbox' checked><span class='slider round'></span></label></td>";
                    innerhtml += "<td><a href='EditExercise.aspx?ExId=" + a.Ex_id + "'><button type='button' style='background-color:#7abd9a' class='btn btn-primary'><i class='fa fa-pencil-square-o'></i></button></a>";
                    innerhtml += "</tr>";
                }

                extable.InnerHtml = innerhtml;
            }
        }

       /* public void btnAddEx_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddExercise.aspx");
        }*/

    }
}