﻿using MoM_Web_Beta.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class Profile : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserType"].ToString().Equals("Counsellor"))
            {
                String innerhtml = "";

                var student = client.GetStudent(Convert.ToInt32(Request.QueryString["StudentNum"]));
                if (student==null) {
                    //if student is null do not redirect
                    return;
                }
                innerhtml += "<div class='title' style='color:#7abd9a'>" + student.studentNumber + "</div>";
                innerhtml += "<h2  style='color: black; font-size:30px'>" + student.Name + " " + student.Surname + "</h2>";
                innerhtml += "<div class='desc'><b>" + student.Name + "</b> is studying towards a <b>" + student.Qualification + "</b>," + getGender(student.gender) + " date of birth is <b>" + student.DOB.Substring(0, 10) + "</b>. <br> This student may be contacted using the following email address: <b>" + student.email + "</b></div>";

                profilecard.InnerHtml = innerhtml;

                //get returned query string and disable the flagged diary entries
                if (Request.QueryString["DiaryID"] !=null && Request.QueryString["isFlagged"]!=null) {
                    if (Convert.ToInt32(Request.QueryString["isFlagged"]) == 1)
                    {
                        //if diary entry is flagged, then remove it from flagged list
                        //mark the diary flag as attended
                        var unflagged = client.RemoveFlagDiaryEntry(Convert.ToInt32(Request.QueryString["DiaryID"]));

                    }
                    else {
                        //else then flag the diary entry
                        var flagged = client.FlagDiaryEntry(Convert.ToInt32(Request.QueryString["DiaryID"]));
                    }

                }
            }
            populateBookings();
            populateDiaries();
            populateSessionNotes();
            populateMood();
            populateMed();
            populatePrescribedExercises();

        }

        public String getGender(Char gen)
        {
            if(gen == 'F')
            {
                return "her";
            }
            else if(gen == 'M')
            {
                return "his";
            }
            else
            {
                return "their";
            }
        }

        public void populateBookings()
        {
            string results = "";
            var bookings = client.getBookings();

            foreach (var a in bookings)
            {
                if (a.studentNum.Equals(Convert.ToInt32(Request.QueryString["StudentNum"])))
                {
                    results += "<tr>";
                    results += "<td style='color:black'>" + a.date.ToString().Substring(0, 9) + "</td>";
                    results += "<td style='color:black'>" + a.time + "</td>";
                    results += "</tr>";
                }

            }
            bookingtable.InnerHtml = results;
        }

        public void populatePrescribedExercises()
        {
            string results = "";
            var preEx = client.getAllPrescribedExercises();

            foreach (var a in preEx)
            {
                if (a.Student_Num.Equals(Convert.ToInt32(Request.QueryString["StudentNum"])))
                {
                    results += "<tr>";

                    String name = null;
                    if (a.Ex_id == 1)
                        name = "Breathing Control";
                    else if (a.Ex_id == 2)
                        name = "Physical Exercise";
                    else if (a.Ex_id == 3)
                        name = "Occupy Your Mind";
                    else if (a.Ex_id == 4)
                        name = "Stop, Think, Do";
                    else if (a.Ex_id == 5)
                        name = "Situational Awareness";

                    results += "<td style='color:black'>" + name + "</td>";
                    results += "<td style='color:black'>" + a.DatePrescribed.ToString().Substring(0, 9) + "</td>";

                    String iscomplete = "Not completed";
                    if (a.IsLatestCompleted == 1)
                    {
                        iscomplete = "Completed";
                    }

                    results += "<td style='color:black'>" + iscomplete + "</td>";
                    results += "</tr>";
                }

            }
            prescriptiontable.InnerHtml = results;
        }


        public void populateDiaries()
        {
            string results = "";

            var diaries = client.GetDiaryEntries(); 
            foreach (var a in diaries)
            {
                string rowcolor = "black";
                if (a.student_Num.Equals(Convert.ToInt32(Request.QueryString["StudentNum"])))
                {
                    string fafacode = "<i class='fa fa-check'>"; 
                    if (a.isFlagged.Equals(1))
                    {
                        //if there is a flag
                        rowcolor = "red";

                    }
                    else if (a.isFlagged.Equals(-1))
                    { 
                        //if it was once flagged, then change the fafa icon to a cross
                        rowcolor = "DarkGreen";
                        fafacode = "<i style='color:red' class='fa fa-remove'>";
                    }
                    else {
                        rowcolor = "lightgray";

                    }
                    var stringfordate = a.date.ToString().Split(' '); //string to remove the 12:00:00
                    results += "<tr>";
                    results += "<td style='color:"+ rowcolor + "'>" + stringfordate[0] + "</td>";
                    //results += "<td style='color:" + rowcolor + "'>" + a.title + "</td>";
                    results += "<td style='color:" + rowcolor + "'>" + a.diaryFlaggedWords + "</td>";
                    //please decide on what this button needs to do (maybe just change color of row when clicked)
                    if (a.isFlagged.Equals(0))
                    {
                        //if the diary entry is not flagged, then there should not be any actions taken on it
                        results += "<td style='color:" + rowcolor + "'>no action</td>";

                    }
                    else {
                        results += "<td><a href='Profile.aspx?StudentNum=" + Convert.ToInt32(Request.QueryString["StudentNum"]) + "&DiaryID=" + a.Diary_id + "&isFlagged=" + a.isFlagged + "'>" + fafacode + "</a></td>";

                    }
                    results += "</tr>";
                }

            }
            diarytable.InnerHtml = results;
        }

        public void populateSessionNotes()
        {
            string results = "";

            var notes = client.GetSessionNotes();
            foreach (var a in notes)
            {
                if (a.student_Num.Equals(Convert.ToInt32(Request.QueryString["StudentNum"])))
                {

                    String severe = null;
                    if (a.rating == 1)
                    {
                        severe = "Mild";
                    }
                    else if (a.rating == 2)
                    {
                        severe = "Moderate";
                    }
                    else if(a.rating == 3)
                    {
                        severe = "Severe";
                    }

                    results += "<tr>";
                    results += "<td style='color:black'>" + a.date.ToString().Substring(0, 10) + "</td>";
                    results += "<td><a href='ViewNote.aspx?SessId=" + a.Session_id + "'><button type='button' style='background-color:#7abd9a' class='btn btn-primary'><i class='fa fa-eye'></i></button></a>";
                    results += "<td style='color:black'>" + severe + "</td>";
                    results += "</tr>";
                }

            }
            notetable.InnerHtml = results;
        }

        public void populateMed()
        {
            string results = "";

            var meds = client.GetMedicines(Convert.ToInt32(Request.QueryString["StudentNum"]));
            foreach (var a in meds)
            {
                if (a.StudentNum.Equals(Convert.ToInt32(Request.QueryString["StudentNum"])))
                {
                    if(a.NameOfMedicine != null)
                    {
                        results += "<tr>";
                        results += "<td style='color:black'>" + a.NameOfMedicine + "</td>";
                        results += "<td style='color:black'>" + a.DoctorName + "</td>";
                        results += "<td style='color:black'>" + a.category + "</td>";
                        results += "</tr>";
                    }
                    else
                    {
                        medvis.Visible = false;
                    }
                }

            }
            medTable.InnerHtml = results;
        }

        public void populateMood()
        {
            string results = "";

            var moods = client.GetMoods();
            foreach (var a in moods)
            {
                if (a.student_Num.Equals(Convert.ToInt32(Request.QueryString["StudentNum"])))
                {
                    String emo = a.emotion;
                    /*if (a.emotion == 1)
                    {
                        emo = "Angry";
                    }
                    else if (a.emotion == 2)
                    {
                        emo = "Sad";
                    }
                    else if (a.emotion == 3)
                    {
                        emo = "Neutral";
                    }
                    else if (a.emotion == 4)
                    {
                        emo = "Happy";
                    }
                    else if (a.emotion == 5)
                    {
                        emo = "Ecstatic";
                    }*/
                    var stringdatelist = a.date.ToString().Split(' ');
                    var stringTimeslist = a.time.ToString().Split('.');
                    results += "<tr>";
                    results += "<td style='color:black'>" + stringdatelist[0] + "</td>";
                    results += "<td style='color:black'>" + stringTimeslist[0] + "</td>";
                    results += "<td style='color:black'>" + emo + "</td>";
                    results += "</tr>";
                }

            }
            moodtable.InnerHtml = results;
        }

        public void btnPreEx_Click(object sender, EventArgs e)
        {
            Response.Redirect("Prescribe.aspx?StudentNum="+ Convert.ToInt32(Request.QueryString["StudentNum"]));
        }

        public void btnAddNote_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddNote.aspx?StudentNum=" + Convert.ToInt32(Request.QueryString["StudentNum"]));
        }

        protected void GoToDashBoard_Click(object sender, EventArgs e)
        {
            Response.Redirect("ProfileReport.aspx?StudentNum=" + Convert.ToInt32(Request.QueryString["StudentNum"]));

        }
    }
}