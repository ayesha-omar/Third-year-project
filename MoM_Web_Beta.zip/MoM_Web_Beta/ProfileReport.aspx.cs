﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class ProfileReport : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public string getBookingsAndRatings()
        {
            //returns a list of booking dates and corresponding ratings
            //format date1;rating1;date2;rating2;date3;rating3;date4;rating4 e.t.c

            string result = "";

            var listratings = client.GetSessionNotes();
            foreach (var a in listratings)
            {
                if (a.student_Num.Equals(Convert.ToInt32(Request.QueryString["StudentNum"]))) //ratings for a specific student
                {
                    result += ";" + a.date.ToString().Substring(0, 10) + ";" + a.rating;

                }
            }

            if (result.Length<=1) {
                result += ";" + "No Logged progress" + ";" + 1;
            }

            return result.Substring(1, result.Length - 1); //exclude the semicolon appended at the end of the string
        }

        //START of the Diary Entries Chart
        public int numDiaryEntries;
        public string getDiaryEntryies()
        {
            //returns a string that contains two data points
            //namely,
            //entryflagged; itsvaluegoeshere
            //entriesNotFlaged; itsvaluegoeshere

            string result="";
            int numflagged = 0;
            int numnotFlagged = 0;

            var diaries = client.GetStudentDiaryEntries(Convert.ToInt32(Request.QueryString["StudentNum"]));
            foreach (var a in diaries)
            {
                if (a.diaryFlaggedWords.Equals("NONE")) //if diary is not flagged
                {
                    numnotFlagged++;
                }
                else {
                    numflagged++;
                }
            }

            //add the collected data to the string output
            result = "Flagged Entries;" + numflagged + ";Entries not Flagged;" + numnotFlagged;
            numDiaryEntries = numflagged + numnotFlagged;
            return result;
        }

        public string getstudentName() {
            var student = client.GetStudent(Convert.ToInt32(Request.QueryString["StudentNum"]));
            return student.Name + " " + student.Surname;
        }
        //END of the Diary Entries Chart

        //TOTAL OVERVIEW STARTS HERE
        /* ['Event', 'Total Number', {role: 'style'}],
                            ['Appointments Booked', 15, 'color: black'],
                            ['Appointments Attended', 10, 'color: black'],
                            ['Total Activities prescribed', 10, 'color: black'],
                            ['Total Activities completed', 7, 'color: black'],*/

        public string getTotalOverviewData()
        {
            string results;
            var bookings = client.getStudentBookings(Convert.ToInt32(Request.QueryString["StudentNum"]));
            var activities = client.getPrescribedExercises(Convert.ToInt32(Request.QueryString["StudentNum"]));
            var sessions = client.GetStudentSessionNotes(Convert.ToInt32(Request.QueryString["StudentNum"]));
            int TotalBookings = 0;
            int bookingsAttended = 0;
            foreach (var a in bookings) {

                foreach (var b in sessions) 
                {
                    if (a.date.ToString().Substring(0,10).Equals(b.date.ToString().Substring(0,10))) {
                        //if the date of booking is the same as the date of the session notes, then the student attended the consultation
                        bookingsAttended++;
                    }
                }
                TotalBookings++;
            }

            int TotalActivities = 0;
            int completedActivities = 0;
            foreach (var a in activities) 
            {
                if (a.IsLatestCompleted.Equals(1)) 
                {
                    completedActivities++;
                }
                TotalActivities++;
            }

            results = "Appointments Booked;" + TotalBookings + ";Appointments Attended;" + bookingsAttended + ";Total Activities Prescribed;" + TotalActivities + ";Total Activities Completed;" + completedActivities;

            return results;
        }
        //TOTAL OVERVIEW ENDS HERE
    }
}