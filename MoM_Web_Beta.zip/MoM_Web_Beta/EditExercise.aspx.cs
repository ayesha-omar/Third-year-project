﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class EditExercise : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            int Exerid = Convert.ToInt32(Request.QueryString["ExId"].ToString());
            var ex = client.GetExercise(Exerid);
            if (ex != null)
            {

                if (!IsPostBack)
                {
                    //exid.Value = Convert.ToString(ex.Ex_id);
                    name.Value = ex.Name;
                    descrip.Value = ex.description;
                    //eximage.Value = ex.mediaPath;
                }

            }
        }

        public void btnSave_Click(object sender, EventArgs e)
        {
            var added = client.EditExercise(Convert.ToInt32(exid.Value), name.Value, descrip.Value, eximage.Value, '1');
            if (added == true)
            {
                Response.Redirect("Exercises.aspx");
            }
        }
    }
}