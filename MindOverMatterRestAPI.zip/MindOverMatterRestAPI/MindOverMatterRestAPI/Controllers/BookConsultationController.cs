﻿using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class BookConsultationController : ApiController
    {

        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/Consultation/book_Consultation")]
        [HttpPost]
        public IHttpActionResult book_Consultation(BookConsultationClass book)
        {
            if (book==null) {
                return Ok(false);
            }
            //new user created
            var booking = new Book_Consultation
            {
                Book_date = book.date,
                Book_time = book.time,
                Student_num = book.studentNum,
                Couns_id = book.Couns_id,

            };

            db.Book_Consultations.InsertOnSubmit(booking);
            try
            {
                db.SubmitChanges();
                //deactive slot
                deactivateSlot(Convert.ToInt32( booking.Couns_id),Convert.ToDateTime(booking.Book_date),booking.Book_time);
                return Ok(true);
            }
            catch (Exception ex)
            {
                ex.GetBaseException();

                return Ok(false);
            }

        }

        [Route("api/Consultation/getBookings")]
        [HttpGet]
        public IHttpActionResult getBookings()
        {
            var bookings = new List<BookConsultationClass>();
            var list = (from a in db.Book_Consultations
                        select a);
            if (list==null) {
                return Ok(false);
            }
            foreach (Book_Consultation a in list)
            {
                BookConsultationClass book = new BookConsultationClass {Book_number=a.Book_number,date=Convert.ToDateTime( a.Book_date),time=a.Book_time,studentNum= Convert.ToInt32(a.Student_num),Couns_id=Convert.ToInt32( a.Couns_id) };
                bookings.Add(book);
            }
            return Ok(bookings); //return List of BookConsultation class
        }


        [Route("api/Consultation/getCounsBookings")]
        [HttpGet]
        public IHttpActionResult getCounsBookings(int counsID)
        {
            var bookings = new List<BookConsultationClass>();
            var list = (from a in db.Book_Consultations
                        where a.Couns_id.Equals(counsID)
                        select a);

            if (list == null)
            {
                return Ok(false);
            }
            foreach (Book_Consultation a in list)
            {
                BookConsultationClass book = new BookConsultationClass { Book_number = a.Book_number, date = Convert.ToDateTime(a.Book_date), time = a.Book_time, studentNum = Convert.ToInt32(a.Student_num), Couns_id = Convert.ToInt32(a.Couns_id) };
                bookings.Add(book);
            }
            return Ok(bookings); //return List of BookConsultation class
        }


        [Route("api/Consultation/getBookingsByStudent")]
        [HttpGet]
        public IHttpActionResult getStudentBookings(int studentid)
        {
            var bookings = new List<BookConsultationClass>();
            var list = (from a in db.Book_Consultations
                        where a.Student_num.Equals(studentid)
                        select a);

            if (list == null)
            {
                return Ok(false);
            }
            foreach (Book_Consultation a in list)
            {
                BookConsultationClass book = new BookConsultationClass { Book_number = a.Book_number, date = Convert.ToDateTime(a.Book_date), time = a.Book_time, studentNum = Convert.ToInt32(a.Student_num), Couns_id = Convert.ToInt32(a.Couns_id) };
                bookings.Add(book);
            }
            return Ok(bookings); //return List of BookConsultation class
        }

        [Route("api/Consultation/getBooking")]
        [HttpPost]
        public IHttpActionResult getBooking(BookConsultationClass bookConsultationClass)
        {
            if (bookConsultationClass==null) {
                return Ok(false);
            }
            var booking = (from a in db.Book_Consultations
                           where a.Couns_id.Equals(bookConsultationClass.Couns_id)
                           && a.Student_num.Equals(bookConsultationClass.studentNum)
                           && a.Book_date.Equals(bookConsultationClass.date)
                           select a).FirstOrDefault();

            if (booking==null) {
                return Ok(false);
            }
            BookConsultationClass booked = new BookConsultationClass { Book_number = booking.Book_number, date = Convert.ToDateTime(booking.Book_date), time = booking.Book_time, studentNum = Convert.ToInt32(booking.Student_num), Couns_id = Convert.ToInt32(booking.Couns_id) };

            return Ok(booked);
        }


        //deactivate slots HELPER function
        private bool deactivateSlot(int userID, DateTime date, string time)
        {
            var slot = (from a in db.UnAvailableDateAndTimes
                        where a.CounsID.Equals(userID) &&
                        a.Date.Equals(date)
                        && a.Time.Equals(time)
                        select a).FirstOrDefault();



            //if the slot is not found, log a new slot in the UNAvailable slots table
            if (slot == null)
            {
                UnAvailableDateAndTime newslot = new UnAvailableDateAndTime
                {
                    CounsID = userID,
                    Date = date,
                    Time = time,
                    isAvailable = 0

                };
                db.UnAvailableDateAndTimes.InsertOnSubmit(newslot);
            }
            else {
                //if the slot is already in the table just disAble it
                slot.isAvailable = 0;
            }
           
            try
            {
                db.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                ex.GetBaseException();

                return false;
            }

            throw new NotImplementedException();
        }

    }
}
