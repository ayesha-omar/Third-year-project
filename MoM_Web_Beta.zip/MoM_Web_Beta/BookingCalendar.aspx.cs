﻿using MoM_Web_Beta.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class BookingCalendar : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            string json = "";
            if (Request.QueryString["timeID"] != null && Request.QueryString["dayID"] != null)
            {
                //monthOF.InnerText = "Halloooo";
                //must display the pop up screen

                if (Request.QueryString["student"] != null)
                {

                    myForm.Visible = true;
                    viewbookinfo.Visible = true;
                    addbook.Visible = false;
                    var student = client.GetStudent(Convert.ToInt32(Request.QueryString["student"]));
                    studentdetails.InnerText = student.studentNumber + " " + student.Surname.Substring(0, 1) + " " + " " + student.Name;
                    //datelbl.InnerText =; initialdate plus date ID
                    datelblbooked.InnerText = "Date: " + (BookingSession.CalendarInitialDate.AddDays(Convert.ToInt32(Request.QueryString["dayID"]))).ToString().Substring(0, 9);
                    //timelbl.innterText= initial time plus time ID
                    timelblbooked.InnerText = "Time: " + (BookingSession.initialTime + Convert.ToInt32(Request.QueryString["timeID"])) + ":00";
                }
                else if (Request.QueryString["unavail"] != null)
                {
                    //making the clicked slot unavailable
                    myForm.Visible = true;
                    addbook.Visible = true;
                    viewbookinfo.Visible = false;
                    datelbl.InnerText = "Date: " + (BookingSession.CalendarInitialDate.AddDays(Convert.ToInt32(Request.QueryString["dayID"]))).ToString().Substring(0, 9);
                    //timelbl.innterText= initial time plus time ID
                    timelbl.InnerText = "Time: " + (BookingSession.initialTime + Convert.ToInt32(Request.QueryString["timeID"])) + ":00";

                    makeavailable.Text = "Unavailable";
                }
                else
                {
                    myForm.Visible = true;
                    addbook.Visible = true;
                    viewbookinfo.Visible = false;
                    //datelbl.InnerText =; initialdate plus date ID
                    datelbl.InnerText = "Date: " + (BookingSession.CalendarInitialDate.AddDays(Convert.ToInt32(Request.QueryString["dayID"]))).ToString().Substring(0, 9);
                    //timelbl.innterText= initial time plus time ID
                    timelbl.InnerText = "Time: " + (BookingSession.initialTime + Convert.ToInt32(Request.QueryString["timeID"])) + ":00";
                    makeavailable.Text = "Make available";
                }
            }

            json = "";
            List<BookConsultationClass> bookings = new List<BookConsultationClass>();
            //var bookings = client.getBookings(); //if the user is the  Admin, they will view all the bookings

            int userid = Convert.ToInt32(Session["UserID"]);
            //if the User is a Counsellor
            if (Session["UserType"].ToString().Equals("Counsellor"))
            {
                bookings = client.getCounsBookings(userid);
                //bookings =client.getCounsBookings(userid);
            }
            //if the user is a Student
            else if (Session["UserType"].ToString().Equals("Student"))
            {
                bookings = client.getStudentBookings(userid);
                // bookings =client.getStudentBookings(userid);
            }
            else
            {
                //if the looged user is an admin
                bookings = client.getBookings();
            }

            //The following code will highlight dates that the Counsellor is booked on
            Calendar1.SelectedDayStyle.BackColor = System.Drawing.Color.Purple;


            foreach (var a in bookings)
            {
                Calendar1.SelectedDates.Add(Convert.ToDateTime(a.date));
            }

            var selecteddates = Calendar1.SelectedDates;

            //Button1.Text = selecteddates[0].DayOfWeek.ToString();

            if (selecteddates.Count != 0)
            {
                Button1.Text = selecteddates[0].DayOfWeek.ToString();
            }


            /*Calendar1.SelectedDates.Add(DateTime.Today);
            Calendar1.SelectedDates.Add(DateTime.Today.AddDays(1));
            Calendar1.SelectedDates.Add(DateTime.Today.AddDays(3));
            Calendar1.SelectedDates.Add(DateTime.Today.AddDays(10));
            Calendar1.SelectedDates.Add(DateTime.Today.AddDays(20));
            Calendar1.SelectedDayStyle.BackColor = System.Drawing.Color.LightCoral;

            foreach (var d in Calendar1.SelectedDates) {
                System.Console.WriteLine(d.ToString()+" ");
            }
            */
            // BookingSession.generateMonthName(month);
            monthOF.InnerText = BookingSession.CalendarInitialDate.Month.ToString();
            string results = "";
            int day = BookingSession.CalendarInitialDate.Day;
            int month = BookingSession.CalendarInitialDate.Month;
            int dayid = BookingSession.getDayOfWeekID(BookingSession.CalendarInitialDate.DayOfWeek.ToString());
            results += "<table style='width:60%;height:50%'>";
            results += "<tr>";
            results += "<th>     </th>";
            results += "<th> Mon " + BookingSession.CalendarInitialDate.AddDays(0).Day + "th</th>";
            results += "<th> Tue " + BookingSession.CalendarInitialDate.AddDays(1).Day + "th </th>";
            results += "<th> Wed " + BookingSession.CalendarInitialDate.AddDays(2).Day + "th </th>";
            results += "<th> Thu " + BookingSession.CalendarInitialDate.AddDays(3).Day + "th </th>";
            results += "<th> Fri " + BookingSession.CalendarInitialDate.AddDays(4).Day + "th </th>";
            //results += "<th> Sat " + BookingSession.CalendarInitialDate.AddDays(5).Day + "th </th>";
           // results += "<th> Sun " + BookingSession.CalendarInitialDate.AddDays(6).Day + "th </th>";
            results += "</tr>";

            monthOF.InnerText = "Month Of " + BookingSession.generateMonthName(month);

            int InitialTime = 8;
            int numWorkHours = 8; //number of hours the Counsellor works
                                  // int i = 0; //times

            //represents the times
            bookings = HelperClass.TrimBookings(bookings,BookingSession.CalendarInitialDate); //returns only bookings for that 7 days time period 
            for (int i = 0; i < numWorkHours; i++)
            {

               // int j = 0; //days
                results += "<tr>";
                //display times on the 1st column
                results += "<td>" + InitialTime + ":00</td>";
                InitialTime++;
                //A table is double array
                //This loop represents the dates/days
                for (int j = 0; j <5; j++)
                {


                    //if this is not the 1st column(which is reserved for the times) display empty/booked sessions
                    //iterate through all the bookings
                    bool bookingFound = false;
                    foreach (var booking in bookings)
                    {

                        DateTime selecteddate = Convert.ToDateTime(booking.date);
                        if (selecteddate.ToString().Substring(0,9).Equals("9/26/2022") && i==4 && j==4)
                        {
                            //then break the program
                            int mm = 2434;
                        }
                        int dayID = BookingSession.getDayOfWeekID(selecteddate.DayOfWeek.ToString()); //get ID of the day
                        int timeID = BookingSession.getTimeOFDayId(booking.time);

                        if ((i == timeID && j == dayID))
                        {
                            Button1.Text = BookingSession.CalendarInitialDate.ToString();
                            if (BookingSession.checkDateRange(BookingSession.CalendarInitialDate, selecteddate))
                            {

                                var student = client.GetStudent(booking.studentNum);
                                string studennname = student.Name.Substring(0,1).ToUpper() + Environment.NewLine + student.Surname;
                                /*<a href='Register.aspx?id=" + a.Id + "'><u>" + a.Name + "</u></a>*/
                                string gebberish = "<a href='BookingCalendar.aspx?timeID=" + timeID + "&dayID=" + dayID + "&student=" + booking.studentNum + "'><h4 style='position:absolute;text-align: center'>" + studennname + "</h4><img src='images/redImage.jpg' alt='' style='margin-left:0px;margin-top:0px;opacity:.4;width:150px;height:80px;background-color:lightgrey;border:black'/></a>";
                                results += "<td>" + gebberish + "</td>";
                                bookingFound = true;
                            }
                            break;
                        }

                    }

                    Boolean unavailableslotfound = false; //boolean if slot available display
                    if (bookingFound == false)
                    {
                        //request UN-available slots, in order to display them on the calander
                        List<AvailableDatesAndTimesClass> availableslots = client.getUnAvailableSlots(Convert.ToInt32(Session["UserID"]));
                        //var availableslots = client.getAvailableSlots(Convert.ToInt32(Session["UserID"]));
                        foreach (var available in availableslots)
                        {
                            DateTime selecteddate = Convert.ToDateTime(available.Date);
                            int dayID = BookingSession.getDayOfWeekID(selecteddate.DayOfWeek.ToString()); //get ID of the day
                            int timeID = BookingSession.getTimeOFDayId(available.Time);

                            if ((i == timeID && j == dayID) && selecteddate > DateTime.Today) //only displays Unavailable bookings for upcoming days
                            {

                                Button1.Text = BookingSession.CalendarInitialDate.ToString();
                                if (BookingSession.checkDateRange(BookingSession.CalendarInitialDate, selecteddate))
                                {
                                    string cellcolor = "lightgrey";
                                    /*if (selecteddate <= DateTime.Today)
                                    {
                                        cellcolor = "DarkGray"; //make colour to be dark gray
                                      
                                        string gebberish = "<a href='BookingCalendar.aspx?timeID=" + i + "&dayID=" + j + "'><img src='images/grayimge.jpg' alt='' style='width:150px;height:80px;background-color:lightgrey;border:gray'/></a>";
                                        results += "<td>" + gebberish + "</td>";
                                        availableslotfound = true;
                                    }
                                    else {*/
                                    /*<a href='Register.aspx?id=" + a.Id + "'><u>" + a.Name + "</u></a>*/
                                    string gebberish = "<a href='BookingCalendar.aspx?timeID=" + timeID + "&dayID=" + dayID + "'><img src='images/whitishimage.png' alt='' style='width:150px;height:80px;background-color:" + cellcolor + ";border:gray'/></a>";
                                    results += "<td>" + gebberish + "</td>";
                                    unavailableslotfound = true;
                                    //}

                                    
                                }

                                break;
                            }

                        }
                    }

                    //TODO: remove Weekends from the list of available dates
                    

                    
                    //display the available slots
                    if (bookingFound == false && unavailableslotfound == false)
                    {
                        
                        string gebberish = "<a href='BookingCalendar.aspx?timeID=" + i + "&dayID=" + j + "&unavail=1'><img src='images/greenCalendar.png' alt='' style='width:150px;height:80px;background-color:lightgrey;border:gray'/></a>";
                        //results += "<td><button style='width:150px;height:120px;background-color:lightgrey;border:none'><a href='index.aspx?timeID=" + i + "&dayID=" + j + "' style='color:lightgrey'></a></button></td>";
                        results += "<td>" + gebberish + "</td>";
                    }

                }

                results += "</tr>";
            }

            results += "</table>";
            scheduler.InnerHtml = results;
        }

        private void popUPScreen()
        {

        }



        protected void btnPrev_Click(object sender, EventArgs e)
        {
            // myForm.Visible = true;
            //redirect to the previous week
            BookingSession.CalendarInitialDate = BookingSession.CalendarInitialDate.AddDays(-7);
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
            // Button1.Text = "PREVIOUS";
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {

            //redirect to the following week
            BookingSession.CalendarInitialDate = BookingSession.CalendarInitialDate.AddDays(7);
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
            // Button1.Text = "NEXT";
        }


        protected void btnmonthview_Click(object sender, EventArgs e)
        {

            //display calendar
            Calendar1.Visible = true;
            scheduler.Visible = false;
            schedulercontrols.Visible = false;
            monthOF.InnerText = "Month View";
            //change monthView button color, to show it is clicked
            btnmonthview.BorderColor = System.Drawing.Color.Aqua;
            //change week view button color
            btnWeekView.BorderColor = System.Drawing.Color.Gray;

        }

        protected void btnWeekView_Click(object sender, EventArgs e)
        {
            Calendar1.Visible = false;

            //display scheduler
            scheduler.Visible = true;
            schedulercontrols.Visible = true;


            //change weekview button color, to show it is clicked
            btnWeekView.BorderColor = System.Drawing.Color.Aqua;
            //change month view button color
            btnmonthview.BorderColor = System.Drawing.Color.Gray;
        }

        protected void btnClosePopUp_Click(object sender, EventArgs e)
        {


            myForm.Visible = false;
            //reset query strings
            Response.Redirect("BookingCalendar.aspx");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //hellow.InnerText = client.GetData(200);
            //client.GetData(200);
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            System.Console.WriteLine("sdsdsdsd dates dates");

            var dates = ((Calendar)sender).SelectedDates;

            int dateID = BookingSession.getDayOfWeekID(dates[0].DayOfWeek.ToString()); //column id in the calendar
            BookingSession.CalendarInitialDate = dates[0].AddDays(-dateID); //change the initial date to the date in the 1st column of the calendar
            Button1.Text = Calendar1.SelectedDate.DayOfWeek.ToString();
            //change the display on the Calander Scheduler
            //from the collection of dates/bookings, 
            //use the initaldate, and add 7 days to it,
            //if in any of the booked dates, are found, display them on the Scheduler
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Home_Click(object sender, EventArgs e)
        {
            Response.Redirect("BookingCalendar.aspx");
        }

        protected void RespondAndRedirect(object sender, EventArgs e)
        {
            Response.Redirect("Contact.aspx");
        }

        protected void btnViewProfile_Click(object sender, EventArgs e)
        {
            Response.Redirect("Profile.aspx?StudentNum=" + Convert.ToInt32(Request.QueryString["student"]));
        }

        protected void makeavailable_Click(object sender, EventArgs e)
        {



            int couns_ID = Convert.ToInt32(Session["UserID"]);
            DateTime date = (BookingSession.CalendarInitialDate.AddDays(Convert.ToInt32(Request.QueryString["dayID"])));
            //timelbl.innterText= initial time plus time ID
            //timelblbooked.InnerText =(BookingSession.initialTime + Convert.ToInt32(Request.QueryString["timeID"])) + ":00:00";
            int time = (BookingSession.initialTime + Convert.ToInt32(Request.QueryString["timeID"]));
            string strtime = "0" + time + ":00:00";
            if (time >= 10)
            {
                strtime = time + ":00:00";
            }
            if (Request.QueryString["unavail"] != null)
            {

                var disabledslot = client.deactivateSlot(couns_ID, date, strtime);
                if (disabledslot == true)
                {
                    Response.Redirect("BookingCalendar.aspx?");
                    return;
                }
            }

            var allocated = client.allocateSlot(couns_ID, date, strtime);
            if (allocated == true)
            {
                Response.Redirect("BookingCalendar.aspx?");
                myForm.Visible = false;
            }
        }
    }
}