﻿using HashPass;
using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class CounsellorController : ApiController
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        [Route("api/Counsellor/EditCounsellor")]
        [HttpPost]
        public IHttpActionResult EditCounsellor(CounsellorClass counsellor)
        {
            if (counsellor==null) {
                //if the given counsellor null
                return Ok(false);
            }

            var couns = (from c in db.Counsellors
                         where c.Couns_id.Equals(counsellor.Couns_id)
                         select c).FirstOrDefault();


            couns.Couns_name = counsellor.Name.Trim();
            couns.Couns_Surname = counsellor.Surname.Trim();
            couns.Couns_email = counsellor.email.Trim();
            couns.isActive = counsellor.isActive;

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();

                return Ok(false);
            }
        }
        
        [Route("api/Counsellor/ActivateCounsellor")]
        [HttpGet]
        public IHttpActionResult ActivateCounsellor(int counsID)
        {
            if (counsID<0) {
                //if the given counsellor null
                return Ok(false);
            }

            var couns = (from c in db.Counsellors
                         where c.Couns_id.Equals(counsID)
                         select c).FirstOrDefault();

            
            couns.isActive ='1'; //activate the Counsellor

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();

                return Ok(false);
            }
        }
        
        [Route("api/Counsellor/DeactivateCounsellor")]
        [HttpGet]
        public IHttpActionResult DeactivateCounsellor(int counsID)
        {
            if (counsID < 0)
            {
                //if the given counsellor null
                return Ok(false);
            }

            var couns = (from c in db.Counsellors
                         where c.Couns_id.Equals(counsID)
                         select c).FirstOrDefault();


            couns.isActive = '0'; //activate the Counsellor

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();

                return Ok(false);
            }
        }


        [Route("api/Counsellor/GetCounsellor")]
        [HttpGet]
        public IHttpActionResult GetCounsellor(int Couns_id)
        {
            var cons = (from a in db.Counsellors
                        where a.Couns_id.Equals(Couns_id)
                        select a).FirstOrDefault();
            if (cons==null) {
                //return false if the 
                return Ok(false);
            }
            CounsellorClass counsellor = new CounsellorClass { Couns_id = cons.Couns_id, Name = cons.Couns_name, Surname = cons.Couns_Surname, email = cons.Couns_email, NumStudentsLinked = Convert.ToInt32(cons.NumStudentsLinked),isActive=cons.isActive ,Admin_id =Convert.ToInt32( cons.Admin_id )};
            return Ok(counsellor);
        }

        [Route("api/Counsellor/GetCounsellors")]
        [HttpGet]
        public IHttpActionResult GetCounsellors()
        {
            List<CounsellorClass> counsellors = new List<CounsellorClass>();
            var list = (from a in db.Counsellors
                        select a);
            if (list == null)
            {
                return Ok(false);
            }
                foreach (Counsellor cons in list)
                {
                    CounsellorClass counsellor = new CounsellorClass { Couns_id = cons.Couns_id, Name = cons.Couns_name, Surname = cons.Couns_Surname, email = cons.Couns_email, NumStudentsLinked = Convert.ToInt32(cons.NumStudentsLinked), isActive = cons.isActive, Admin_id = Convert.ToInt32(cons.Admin_id) };

                    counsellors.Add(counsellor);
                }
            
            return Ok(counsellors);
        }

        

        [Route("api/Counsellor/AddCounsellor")]
        [HttpPost]
        public IHttpActionResult AddCounsellor(CounsellorClass counsellor)
        {
            if (counsellor==null) {
                //check the validity of the counsellor
                return Ok(false);
            }

            var newCouns = new Counsellor
            {
                Couns_name = counsellor.Name,
                Couns_Surname = counsellor.Surname,
                Couns_email = counsellor.email,
                Couns_password = Secrecy.HashPassword(counsellor.password),
                isActive='0'
            };

            db.Counsellors.InsertOnSubmit(newCouns);

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException e)
            {
                e.GetBaseException();
                return Ok(false);
            }
        }

        [Route("api/Counsellor/getMinCounsellor")]
        [HttpGet]
        public IHttpActionResult getMinCounsellor()
        {

            //determined by using the Min calculation algorithm
            Counsellor nextCouns = new Counsellor();
            var list = (from a in db.Counsellors
                        where a.isActive.Equals('1')
                        select a); //get all the  counsellors that are active
            List<Counsellor> counsellors = new List<Counsellor>(list);
            int min = 10000000;
            if (list==null)
            {
                return Ok(false); //if there are no counsellors on the system
            }

            nextCouns = counsellors[0]; //return the 1st counsellor on the table
            min = nextCouns.NumStudentsLinked;
            foreach (Counsellor c in counsellors)
            {
                if (c.NumStudentsLinked < min)
                {
                    nextCouns = c;
                    min = c.NumStudentsLinked; //update min value
                }
            }
            CounsellorClass counsellorClass = new CounsellorClass {Couns_id=nextCouns.Couns_id, Name=nextCouns.Couns_name, Surname=nextCouns.Couns_Surname, email=nextCouns.Couns_email, NumStudentsLinked=nextCouns.NumStudentsLinked, isActive=nextCouns.isActive };
            return Ok(nextCouns);

        }

        [Route("api/Counsellor/GetCounsellorStudents")]
        [HttpGet]
        public IHttpActionResult GetCounsellorStudents(int counsID)
        {
            List<StudentClass> linkedstudents = new List<StudentClass>();

            var list = (from a in db.StuCounsLinks
                        where a.couns_id.Equals(counsID)
                        select a);

            foreach (var a in list)
            {
                Student studentobj = GetStudent(Convert.ToInt32(a.Stu_Num));
                //create the studentClass
                StudentClass student = new StudentClass { studentNumber=studentobj.Student_num, Name=studentobj.Stu_name,Surname=studentobj.Stu_surname,email=studentobj.Stu_email};
                linkedstudents.Add(student);
            }
            return Ok(linkedstudents);
        }


        //HELPER FUNCTION
        public Student GetStudent(int Student_nim)
        {
            var student = (from a in db.Students
                           where a.Student_num.Equals(Student_nim)
                           select a).FirstOrDefault();

            return student;
        }

        
    }
}
