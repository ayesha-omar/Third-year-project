﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;

namespace MindOverMatterRestAPI.Models
{
    public class StuCounsLinkController : ApiController
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/StuCounsLink/getLinkInfoByStudent")]
        [HttpGet]
        public IHttpActionResult getLinkInfoByStudent(int stunum)
        {
            var obj = (from a in db.StuCounsLinks
                        where a.Stu_Num.Equals(stunum)
                        select a).FirstOrDefault();
            if (obj==null) {
                return Ok(false);
            }
            StuCounsLinkClass link = new StuCounsLinkClass {LinkID=obj.LinkID,couns_id=Convert.ToInt32(obj.couns_id),Student_Num= Convert.ToInt32(obj.Stu_Num),isLinked= Convert.ToInt32(obj.islinked) };

            return Ok(link);
        }

        [Route("api/StuCounsLink/LinkStudentToCounsellor")]
        [HttpPost]
        public IHttpActionResult LinkStudentToCounsellor(StuAndCounsIDPair stuAndCounsIDPair)
        {
            var couns = (from a in db.Counsellors
                         where a.Couns_id.Equals(stuAndCounsIDPair.CounsID)
                         select a).FirstOrDefault();


            StuCounsLink counsLink = new StuCounsLink
            {
                couns_id = stuAndCounsIDPair.CounsID,
                Stu_Num = stuAndCounsIDPair.StudentNum,
                islinked = 1
            };

            //edit the number of students linked to counsellor

            //save changes
            couns.NumStudentsLinked = couns.NumStudentsLinked + 1;
            db.StuCounsLinks.InsertOnSubmit(counsLink);
            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();
                return Ok(false);
            }
        }


        [Route("api/StuCounsLink/UnLinStudentFromCounsellor")]
        [HttpPost]
        public IHttpActionResult UnLinStudentFromCounsellor(StuAndCounsIDPair stuAndCounsIDPair)
        {
            var CSlink = (from a in db.StuCounsLinks
                          where a.couns_id.Equals(stuAndCounsIDPair.CounsID)
                          && a.Stu_Num.Equals(stuAndCounsIDPair.StudentNum)
                          select a).FirstOrDefault();
            CSlink.islinked = 0;

            var couns = (from a in db.Counsellors
                         where a.Couns_id.Equals(stuAndCounsIDPair.CounsID)
                         select a).FirstOrDefault();

            //edit the number of students linked to counsellor
            if (CSlink != null)
            {
                couns.NumStudentsLinked = couns.NumStudentsLinked - 1;
            }

            try
            {
                //save changes
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();
                return Ok(false);
            }
        }

    }
}
