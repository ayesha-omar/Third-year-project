﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoM_Web_Beta.Models
{
    class AvailableTimesOnly
    {

        public string time { get; set; }

    }
}
