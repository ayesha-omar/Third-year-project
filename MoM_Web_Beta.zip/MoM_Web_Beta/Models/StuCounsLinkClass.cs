﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MoM_Web_Beta.Models
{
    public class StuCounsLinkClass
    {

        public int LinkID { get; set; }
        public int couns_id { get; set; }
        public int Student_Num { get; set; }
        public int isLinked { get; set; }

    }
}