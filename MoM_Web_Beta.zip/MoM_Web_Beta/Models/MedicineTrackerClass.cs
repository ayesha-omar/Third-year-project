﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MoM_Web_Beta.Models
{
    public class MedicineTrackerClass
    {

        public int ID { get; set; }
        public DateTime date { get; set; }
        public string NameOfMedicine { get; set; }

        public string category { get; set; }

        public int StudentNum { get; set; }

        public string DoctorName { get; set; }
    }
}