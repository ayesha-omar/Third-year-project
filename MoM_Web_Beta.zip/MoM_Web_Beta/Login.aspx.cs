﻿using MoM_Web_Beta.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class Login : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserType"] != null) //if user is logged in
            {
                Response.Redirect("BookingCalendar.aspx");
            }
           
        }
        public void btnLogin_Click(object sender, EventArgs e)
        {
            var user = client.loginUser(email.Value, HashPass.Secrecy.HashPassword( password.Value));

           // var user = client.loginUser(email.Value, password.Value);

            if (user != null)
            {
                Session["UserType"] = user.userType;
                Session["UserID"] = user.UserId;
                Session["Username"] = user.Name+" "+user.surname;

                if (Session["UserType"].ToString().Equals("Counsellor"))
                {
                    Response.Redirect("BookingCalendar.aspx");
                }
                else if (Session["UserType"].ToString().Equals("Admin"))
                {
                    Response.Redirect("Counsellors.aspx");
                }
                else
                {
                    var link = client.getLinkInfoByStudent(user.UserId);
                    if (link != null)
                    {
                        Session["myCounsID"] = link.couns_id;
                    }
                    Response.Redirect("Calendar.aspx");
                }
                Console.WriteLine("writeline " + user.Name);
            }
            else
            {
                errorlogin.Visible = true;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}