﻿using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class MoodController : ApiController
    {

        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/Mood/GetMoods")]
        [HttpGet]
        public IHttpActionResult GetMoods()
        {
            List<MoodClass> moods = new List<MoodClass>();
            var list = (from a in db.Moods
                        select a);
            if (list==null) {
                return Ok(false); //return false if the list is null
            }
            foreach (var a in list)
            {
                MoodClass mood = new MoodClass { Mood_id = a.Mood_Id, time = a.Mood_Time, date = Convert.ToDateTime(a.Mood_Date), emotion = a.Mood_Emotion, student_Num = Convert.ToInt32(a.Student_Num) };
                moods.Add(mood);
            }

            return Ok(moods);
        }

        [Route("api/Mood/getMood")]
        [HttpGet]
        public IHttpActionResult getMood(int id)
        {
            //get the specified mood
            var mood = (from a in db.Moods
                        where a.Mood_Id.Equals(id)
                        select a).FirstOrDefault();
            if (mood == null)
            {
                return Ok(false);
            }

            MoodClass moodClass = new MoodClass { Mood_id = mood.Mood_Id, date = Convert.ToDateTime(mood.Mood_Date), time = mood.Mood_Time, emotion = mood.Mood_Emotion, student_Num = Convert.ToInt32(mood.Student_Num) };

            return Ok(moodClass);
        }
        
        [Route("api/Mood/LogMood")]
        [HttpPost]
        public IHttpActionResult LogMood(MoodClass mood)
        {
            //add new mood
            if (mood == null)
            {
                return Ok(false);
            }

            Mood moodClass = new Mood
            {
             Mood_Date = Convert.ToDateTime(mood.date).Date,
             Mood_Time = mood.time,
             Mood_Emotion = mood.emotion,
             Student_Num = mood.student_Num,
            };

            db.Moods.InsertOnSubmit(moodClass);

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (Exception ex)
            {
                ex.GetBaseException();

                return Ok(false);
            }

        }

    }
}
