﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoM_Web_Beta.Models
{
    public class PrescribedExercise
    {

       public string exerciseName { get; set; }
       public int exerciseID { get; set; }

        
    }
}
