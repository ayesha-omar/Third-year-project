﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoM_Web_Beta.Models
{
    class PreviousBookings
    {

        public string date { get; set; }
        public string timeslot { get; set; }
        public string description { get; set; }

    }
}
