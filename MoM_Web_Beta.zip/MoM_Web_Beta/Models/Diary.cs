﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoM_Web_Beta.Models
{
    public class Diary
    {
        public int DiaryId { get; set; }
        public string DiaryTitle { get; set; }
        public string DiaryDescription { get; set; }

       

    }
}
