﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoM_Web_Beta.Models
{
    class StuAndCounsIDPair
    {
        public int StudentNum { get; set; }
        public int CounsID { get; set; }

    }
}
