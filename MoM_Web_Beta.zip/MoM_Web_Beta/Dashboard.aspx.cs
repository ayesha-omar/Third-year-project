﻿using MoM_Web_Beta.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class Dashboard : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();
        public static System.Web.Script.Serialization.JavaScriptSerializer oSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        protected void Page_Load(object sender, EventArgs e)
        {
            generateCounsBookingsData(); //generate data sets for counsellors and their yearly bookings
            //ScriptManager.RegisterStartupScript(this, GetType(), "myFunction", "myFunction();", true);

        }

       
        public string sJSON() { 
            return oSerializer.Serialize(HelperClass.counsBookingsDatas); ;
        }
        public string getCounsellorsNames() {
            var counsellors = client.GetCounsellors();
            string results = "";

            for (int i=0;i<counsellors.Count;i++) {
                results += counsellors[i].Name;
                if (i<counsellors.Count-1)
                {
                    results += ";";
                }
            }
            return results;
        }

        public int NumCounsellors()
        {
            //returns the number of counsellors
            var counsellors = client.GetCounsellors();
            return counsellors.Count;
        }

        //helper class to generate the CounsBookingsData classes for every counsellor
        private void generateCounsBookingsData()
        {
            //renew the current list
            HelperClass.counsBookingsDatas = new List<CounsBookingsData>();
            //Create the CounsBookingDatas initial data sets
            var counsellors = client.GetCounsellors();
            foreach (var a in counsellors)  // another reason counsellors are generated first is because the order in the datalist to be used matters (needs to correspond with the front end returned counsellor names used for coulumns -#function getCounsellorsNames() )
            {
                CounsBookingsData counsBookingsData = new CounsBookingsData 
                {
                    CounsID = a.Couns_id //initally mon to december are zero, will be initalized on the next lines of Code
                    };
                //add this data set to the list
                HelperClass.counsBookingsDatas.Add(counsBookingsData);
            }

            var bookings = client.getBookings();
            foreach (var a in bookings) 
            {
                foreach(var b in HelperClass.counsBookingsDatas) {
                    if (a.Couns_id.Equals(b.CounsID)) {
                        string monthname =BookingSession.generateMonthName(a.date.Month); //generate the name of the month for this boooking
                        b.IncrementForMonth(monthname); //increment the number of bookings for this month
                        //exit this current loop since the counsellor is found
                        continue;
                    }
                }
            }
        }

        //this function will generate the data/combine the already existing data -#funtion call generateCounsBookingsData()- of Counsellor and number of bookings, and return them as a string
        public string getCounsBookingsData() {
            

            string results = ""; //string format is  MonthName;COuns1Data;Couns2data;Couns3data;...N;
            var counsBookingsDatasets = HelperClass.counsBookingsDatas;
            List<String> monthNames =new List<string>{"January","February","March","April","May","June","July","August","September","October","November","December"};
            
            foreach (var monthname in monthNames) {

                if (!monthname.Equals("January"))
                {
                    results += ";" + monthname;
                }
                else {
                    results += monthname;
                }
                foreach (var dataset in counsBookingsDatasets) {
                    results+=";"+dataset.getDataForMonth(monthname);

                }
            }
            
            return results;
        }



        public string getCounsellorStudentsData() {
            //will return string containing data for each counsellor and their number of students
            string results = "";
            //get counsellors
            var counsellors = client.GetCounsellors();
            int counter= counsellors.Count;
            foreach (var c in counsellors) {
                results += c.Name+";"+c.NumStudentsLinked;

                if (counter>1) {
                    results += ";"; //only add this separator if we still have counsellors on the loop
                }
                counter--;
            }

            return results;
        }

        //returns the Student Mental health ratings from 1 to 3
        public string getRatingValues() {
            //the higher the rating the serious the anxiety
            string values = ""; //FORMAT: GOOD;MILD;NOTGOOD
            
            var sessionNotes = client.GetSessionNotes();
            //we only need to use latest Ratings in our dashboards
            var latestsessionnotes = GetLatestSessionNotesClasses(sessionNotes);
            int good = 0;
            int mild = 0;
            int notgood = 0;

            foreach (var a in latestsessionnotes) 
            {
                switch (a.rating)
                {
                    case 1:
                        good++;
                        break;
                    case 2:
                        mild++;
                        break;
                    case 3:
                        notgood++;
                        break;
                }
            }

            //add the values to the resulting dataset string
            values += good + ";" + mild + ";" + notgood;
            return values;

        }

        
        public List<SessionNotesClass> GetLatestSessionNotesClasses(List<SessionNotesClass> sessionNotes) 
        {
            //var sessionNotes = client.GetSessionNotes();
            List<SessionNotesClass> latestSessionNotes = new List<SessionNotesClass>();
            latestSessionNotes.Add(sessionNotes[sessionNotes.Count-1]); //initialize the list with a single element to support the second loop
            for (int i=sessionNotes.Count-1;i>=0;i--)  //taking the last from the list (taking the latest ratings)
            {
                bool latestisfound = true;
                foreach(var b in latestSessionNotes) {
                   
                    if ((b.student_Num.Equals(sessionNotes[i].student_Num))) //if the Student with this session is not in the list for latest sessions
                    {
                        latestisfound = false;
                        break;
                    }
                }

                if (latestisfound==true) 
                {

                    latestSessionNotes.Add(sessionNotes[i]);
                }
                
            }
            return latestSessionNotes;
        }

        public string getExercisesStats() {
           
            string results = "";     //Format ExerciseName;NumOfPrescribedExercises;NumOfCompletedExercise
            //client.getExercises();
            var exercises = client.GetExercises();
            var prescribedExercises = client.getAllPrescribedExercises();
            int numExercises = exercises.Count;
            int finallength = numExercises * 3;
            int counter = 0; //keep track of the cursor
            foreach (var ex in exercises) {
                results +=ex.Name+";";
                results += getNumPrescribed(ex.Ex_id, prescribedExercises) + ";";
                results += getNumCompleted(ex.Ex_id, prescribedExercises);
                if (counter < finallength - 1)
                {
                    results += ";";
                }
                counter++;
            }
            return results;
            //generate the needed information
            //add the relevant information using the above mentioned format
            /*//example
            //length of this loop should be numExercise times 3 (since each exercise's data set should take up to 3 indices)
            for (int i=0;i< finallength; i=i+3) {
                results += "exercisename" + i + ";" + i + 1 + ";" + i + 2; //format Name;NumPrescribedEx;NumcompletedEx
                if (i< finallength - 1) {
                    results += ";";
                }
            }*/

        }

        //will generate and return the number of completed exercises
        public int getNumCompleted(int exerciseID,List<PrescribeExerciseClass> prescribeExerciseClasses) 
        {

            int completed = 0;
            foreach (var a in prescribeExerciseClasses)
            {
                if (a.Ex_id.Equals(exerciseID)) //checks 
                {
                    if (a.IsLatestCompleted.Equals(1)) //if this prescription was completed increment by one
                    {
                        completed++; //increment number of completed exercises by one
                    }

                }

            }
            return completed;
        }

        public int getNumPrescribed(int exerciseID, List<PrescribeExerciseClass> prescribeExerciseClasses) 
        {
            int prescribed = 0;
            foreach (var a in prescribeExerciseClasses)
            {
                if (a.Ex_id.Equals(exerciseID)) {
                    prescribed++; //increment num of compl
                }
                
            }
            return prescribed;
        }
    }
}