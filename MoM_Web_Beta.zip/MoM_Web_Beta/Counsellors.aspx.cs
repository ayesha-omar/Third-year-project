﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class Counsellors : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserType"].ToString().Equals("Admin"))
            {
                String innerhtml = "";
                //int counsID = Convert.ToInt32(Session["UserID"].ToString());
                //get students linked to this Counsellor
                //var users = client.GetCounsellorStudents(counsID);
                var users = client.GetCounsellors();

                foreach (var a in users)
                {
                    string ischecked = "";
                    if (a.isActive.Equals('1')) {
                        ischecked = "checked";
                    
                    }
                    // href'Counsellors.aspx'
                    innerhtml += "<tr>";
                    innerhtml += "<td>" + a.Name + "</td>";
                    innerhtml += "<td>" + a.Surname + "</td>";
                    innerhtml += "<td>" + a.email + "</td>";
                    innerhtml += "<td>" + a.NumStudentsLinked + "</td>";
                    innerhtml += "<td><label id='toggleActive' class='switch'><input type='checkbox' "+ ischecked + " ><span class='slider round'></span></label></td>";
                    innerhtml += "<td><a href='EditCounsellor.aspx?CounsId=" + a.Couns_id + "'><button type='button' style='background-color:#7abd9a' class='btn btn-primary'><i class='fa fa-pencil-square-o'></i></button></a>";
                    innerhtml += "</tr>";

                }

                usertable.InnerHtml = innerhtml;
            }
        }

        public void btnAddCouns_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddCounsellor.aspx");
        }
    }
}