﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class EditCounsellor : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            int Couid = Convert.ToInt32(Request.QueryString["CounsId"].ToString());
            var couns = client.GetCounsellor(Couid);
            if (couns != null)
            {
                if (couns.isActive.Equals('0')) //if counsellor is not active, change button name to activate
                {
                    btnActivate.Text = "Activate Counsellor";
                }
                else {
                    btnActivate.Text = "De-Activate Counsellor";
                }
                if (!IsPostBack)
                {
                    counsid.Value = Convert.ToString(couns.Couns_id);
                    name.Value = couns.Name;
                    surname.Value = couns.Surname;
                    email.Value = couns.email;
                    passw.Value = couns.password;
                }
            }
        }

        public void btnSave_Click(object sender, EventArgs e)
        {

            var added = client.EditCounsellor(Convert.ToInt32(counsid.Value), name.Value, surname.Value, Convert.ToString(email.Value));
            if (added == true)
            {
                Response.Redirect("Counsellors.aspx");
            }
        }

        protected void btnDeActivate_Click(object sender, EventArgs e)
        {
            
            var counsellor = client.GetCounsellor(Convert.ToInt32(Request.QueryString["CounsId"]));
            if (counsellor != null)
            {
                if (counsellor.isActive.Equals('1')) //if the counsellor is activated, then deactivate 
                {
                    var isactivated= client.DeactivateCounsellor(counsellor.Couns_id);
                    if (isactivated==true)
                    {
                        //then cancellor is deactivated
                        Response.Redirect("Counsellors.aspx");
                    }
                }
                else //if counsellor is deactivated then activate
                {
                    var isDeActivated = client.ActivateCounsellor(counsellor.Couns_id);
                    //
                    if(isDeActivated==true) 
                    {
                        //then cancellor is Activated
                        Response.Redirect("Counsellors.aspx");
                    }
                }
            }
        }
    }
}