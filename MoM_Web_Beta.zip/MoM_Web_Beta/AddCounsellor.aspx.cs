﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class AddCounsellor : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void btnSave_Click(object sender, EventArgs e)
        {
            var added = client.AddCounsellor(name.Value, surname.Value, email.Value, passw.Value);
            if (added == true)
            {
                Response.Redirect("Counsellors.aspx");
            }
        }
    }
}