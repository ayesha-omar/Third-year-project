﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MindOverMatterRestAPI.Models
{
    public class NotificationClass
    {
        public int ID { get; set; }
        public DateTime DateOfNotification { get; set; }
        public string description { get; set; }
        public string isActive { get; set; }
        
        public int StudentNum { get; set; }

        public int CounsID { get; set; }

    }
}