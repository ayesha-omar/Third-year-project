﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MoM_Web_Beta
{
    public partial class Students : System.Web.UI.Page
    {
        ServiceReference.MoMServiceClient client = new ServiceReference.MoMServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserType"].ToString().Equals("Counsellor"))
            {
                String innerhtml = "";
                int counsID = Convert.ToInt32(Session["UserID"].ToString());
                //get students linked to this Counsellor
                var users = client.GetCounsellorStudents(counsID);
                // var users = client.GetStudents();
                
                foreach (var a in users)
                {
                    string markStudent = "";
                    if (check_IF_flagged(a.studentNumber)==true) {
                        markStudent = "<i style='color:red' class='fa fa-circle'></i>";
                    }
                    innerhtml += "<tr>";
                    innerhtml += "<td><p>" + markStudent + a.studentNumber+ "</p></td>";
                    innerhtml += "<td>" + a.Name + "</td>";
                    innerhtml += "<td>" + a.Surname + "</td>";
                    innerhtml += "<td>" + a.email + "</td>";
                    innerhtml += "<td><a href='Profile.aspx?StudentNum=" + a.studentNumber + "'><button type='button' style='background-color:#7abd9a' class='btn btn-primary'><i class='fa fa-eye'></i></button></a>";
                    innerhtml += "</tr>";
                }

                usertable.InnerHtml = innerhtml;
            }
        }

        public bool check_IF_flagged(int studentNum) 
        {
            var entries = client.GetStudentDiaryEntries(studentNum);
            bool isflaged = false;
            foreach (var a in entries) {
                if (a.isFlagged.Equals(1))
                {
                    isflaged = true; //if there is atleast one flagged entry, then set to true
                    break;
                }
            }
            return isflaged;
        }
    }

}