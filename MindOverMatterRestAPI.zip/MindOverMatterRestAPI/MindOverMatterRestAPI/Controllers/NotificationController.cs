﻿using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class NotificationController : ApiController
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/Notification/GetNotification")]
        [HttpGet]
        public IHttpActionResult GetNotification(int studentNum)
        {
            var notific = (from a in db.Notifications
                           where a.isActive.Equals("1")
                           && a.StudentNum.Equals(studentNum)
                           select a).FirstOrDefault(); //get the 1st notification that is active in the table

            if (notific==null) {
                return Ok(false); //if there is no active notification
            }
            var deact=DeActivateNotification(notific.Id); //deactivate exercise
            
            NotificationClass notificationClass = new NotificationClass { ID=notific.Id,DateOfNotification=notific.DateOfNotification,description=notific.Description,isActive=notific.isActive};
            return Ok(notificationClass);
        }

        [Route("api/Notification/DeActivateNotification")]
        [HttpGet]
        public IHttpActionResult DeActivateNotification(int notificID)
        {
            var notific = (from a in db.Notifications
                           where a.isActive.Equals("1")
                           && a.Id.Equals(notificID)
                           select a).FirstOrDefault(); //get the 1st notification that is active in the table

            
                notific.isActive = "0"; //disable notification
            

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException exerption)
            {
                exerption.GetBaseException();

                return Ok(false);
            }


        }

        [Route("api/Notification/GetAllNotifications")]
        [HttpGet]
        public IHttpActionResult GetAllNotifications()
        {
            List<NotificationClass> notificationClasses = new List<NotificationClass>();
            var notifics = (from a in db.Notifications
                           select a); //get the 1st notification that is active in the table

            foreach (var a in notifics) {
                NotificationClass notificationClass = new NotificationClass { ID = a.Id, DateOfNotification = a.DateOfNotification, description = a.Description, isActive = a.isActive };
                notificationClasses.Add(notificationClass);

            }
            return Ok(notificationClasses);

        }

        [Route("api/Notification/AddNotification")]
        [HttpPost]
        public IHttpActionResult AddNotification(NotificationClass notification)
        {
            Notification newnotification = new Notification
            {
                DateOfNotification = DateTime.Now,
                CounsellorID=notification.CounsID,
                StudentNum=notification.StudentNum,
                Description = notification.description,
                isActive = "1"
            };

            db.Notifications.InsertOnSubmit(newnotification);

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException exerption)
            {
                exerption.GetBaseException();

                return Ok(false);
            }

        }





    }
}
