﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MoM_Web_Beta.Models
{
    public class SessionNotesClass
    {
        public int Session_id { get; set; }
        public DateTime date { get; set; }
        public string description { get; set; }
        public int rating { get; set; }
        public int student_Num { get; set; }
        public int Couns_id { get; set; }
    }
}