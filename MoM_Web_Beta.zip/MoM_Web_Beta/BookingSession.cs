﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MoM_Web_Beta
{
    public class BookingSession
    {



        public static int DayOfWeekId { get; set; }
        public static int TimeOFDayId { get; set; }
        public static DateTime CalendarInitialDate { get; set; } = (DateTime.Today.AddDays(-BookingSession.getDayOfWeekID(DateTime.Today.DayOfWeek.ToString())));
        public static int initialTime { get; set; } = 8;

        public static List<BookingSession> bookingsessions { get; set; } //set default inital DATETIME

        public BookingSession(string day, string time)
        {
            DayOfWeekId = getDayOfWeekID(day);
            TimeOFDayId = getTimeOFDayId(time);
        }

        public static int getDayOfWeekID(string DAY)
        {
            int id = 1000;
            //determine what ID does the DAY belong to
            switch (DAY.ToUpper())
            {
                case "MONDAY":
                    id = 0;
                    break;
                case "TUESDAY":
                    id = 1;
                    break;

                case "WEDNESDAY":
                    id = 2;
                    break;
                case "THURSDAY":
                    id = 3;
                    break;
                case "FRIDAY":
                    id = 4;
                    break;
                case "SATURDAY":
                    id = 5;
                    break;
                case "SUNDAY":
                    id = 6;
                    break;
                default:
                    id = 1000;
                    break;
            }

            return id;
        }

        public static int getTimeOFDayId(string time)
        {
            /* int starttime = 8;
             int endtime = 17;

             List<String> stringTimes = new List<String>();

             for (int i=starttime;i<=endtime;i++) {
                 stringTimes.Add(i.ToString()+":00");
             }
             */
            int id = 10000;
            switch (time.ToUpper())
            {
                case "08:00:00":
                    id = 0;
                    break;
                case "09:00:00":
                    id = 1;
                    break;

                case "10:00:00":
                    id = 2;
                    break;
                case "11:00:00":
                    id = 3;
                    break;
                case "12:00:00":
                    id = 4;
                    break;
                case "13:00:00":
                    id = 5;
                    break;
                case "14:00:00":
                    id = 6;
                    break;
                case "15:00:00":
                    id = 7;
                    break;
                case "16:00:00":
                    id = 8;
                    break;
                case "17:00:00":
                    id = 9;
                    break;
                default:
                    id = 1000;
                    break;
            }

            return id;
        }

        public static bool checkDateRange(DateTime initialDate, DateTime CurrentDate)
        {

            //if the current day is in the seven days range
            int dayID = getDayOfWeekID(initialDate.DayOfWeek.ToString()); //get day ID

            if (CurrentDate >= initialDate.AddDays(-dayID) && CurrentDate <= initialDate.AddDays(6 - dayID))
            {
                return true;
            }
            return false;

        }

        public static string generateMonthName(int month)
        {
            string monthname = "Uknown Month";
            switch (month)
            {
                case 1:
                    monthname = "January";
                    break;
                case 2:
                    monthname = "February";
                    break;

                case 3:
                    monthname = "March";
                    break;
                case 4:
                    monthname = "April";
                    break;
                case 5:
                    monthname = "May";
                    break;
                case 6:
                    monthname = "June";
                    break;
                case 7:
                    monthname = "July";
                    break;
                case 8:
                    monthname = "August";
                    break;
                case 9:
                    monthname = "September";
                    break;
                case 10:
                    monthname = "October";
                    break;
                case 11:
                    monthname = "November";
                    break;
                case 12:
                    monthname = "December";
                    break;
                default:
                    monthname = "Uknown Month";
                    break;
            }
            return monthname;

        }

    }
}