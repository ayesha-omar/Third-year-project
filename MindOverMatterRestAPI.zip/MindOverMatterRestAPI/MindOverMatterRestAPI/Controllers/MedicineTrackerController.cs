﻿using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class MedicineTrackerController : ApiController
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/Medicine/GetMedicine")]
        [HttpGet]
        public IHttpActionResult GetMedicine(int medicineID)
        {

            var med = (from a in db.MeidicineTrackers
                       where a.Id.Equals(medicineID)
                       select a).FirstOrDefault();

            if (med==null) 
            {
                return Ok(false);
            }

            MedicineTrackerClass medicineTrackerClass = new MedicineTrackerClass {ID=med.Id,date=med.Date,NameOfMedicine=med.NameOfMed,category=med.Category,StudentNum=med.StudentNum,DoctorName=med.NameOfDoctor, isActive=Convert.ToInt32(med.isActive) };

            return Ok(medicineTrackerClass);
        }
        
        [Route("api/Medicine/GetMedicines")]
        [HttpGet]
        public IHttpActionResult GetMedicines(int studentNum)
        {
            List<MedicineTrackerClass> medicines = new List<MedicineTrackerClass>();
            var list = (from a in db.MeidicineTrackers
                        where a.StudentNum.Equals(studentNum)
                        select a);

            foreach (var med in list) {
                MedicineTrackerClass medicineTrackerClass = new MedicineTrackerClass { ID = med.Id, date = med.Date, NameOfMedicine = med.NameOfMed, category = med.Category, StudentNum = med.StudentNum, DoctorName = med.NameOfDoctor, isActive = Convert.ToInt32(med.isActive) };

                medicines.Add(medicineTrackerClass);
            }

            return Ok(medicines);


        }
        
        [Route("api/Medicine/LogMedicine")]
        [HttpPost]
        public IHttpActionResult LogMedicine(MedicineTrackerClass medicine)
        {
            if (medicine==null) {
                return Ok(false);
            }

            MeidicineTracker medicineTracker = new MeidicineTracker 
            {
            Date = medicine.date,
            NameOfMed = medicine.NameOfMedicine,
            Category = medicine.category,
            StudentNum = medicine.StudentNum,
            NameOfDoctor = medicine.DoctorName,
            isActive=1,
        };
            db.MeidicineTrackers.InsertOnSubmit(medicineTracker);
            try
            {
                //save changes
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();
                return Ok(false);
            }
          
        }
        
        [Route("api/Medicine/RemoveMedicine")]
        [HttpGet]
        public IHttpActionResult RemoveMedicine(int medicineID)
        {
            var medicine = (from a in db.MeidicineTrackers
                            where a.Id.Equals(medicineID)
                            select a).FirstOrDefault();

            if (medicine == null) {
                return Ok(false);
            }

            medicine.isActive = 0; //deactivate
            try
            {
                //save changes
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();
                return Ok(false);
            }
          
        } 
        
        [Route("api/Medicine/EditMedicine")]
        [HttpPost]
        public IHttpActionResult EditMedicine(MedicineTrackerClass medicine)
        {
            if (medicine==null) {
                return Ok(false);
            }

            var med = (from a in db.MeidicineTrackers
                       where a.Id.Equals(medicine.ID)
                       select a).FirstOrDefault();

            if (med==null) {
                return Ok(false);
            }

            med.Date = medicine.date;
            med.NameOfMed = medicine.NameOfMedicine;
            med.Category = medicine.category;
            med.StudentNum = medicine.StudentNum;
            med.NameOfDoctor = medicine.DoctorName;
            try
            {
                //save changes
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();
                return Ok(false);
            }
          
        }




    }
}
