﻿using MindOverMatterRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;

namespace MindOverMatterRestAPI.Controllers
{
    public class ExerciseController : ApiController
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        [Route("api/Exercise/ActivateExercise")]
        [HttpGet]
        public IHttpActionResult ActivateExercise(int exerciseid)
        {
  
            var ex = (from a in db.Exercises
                      where a.Ex_id.Equals(exerciseid)
                      select a).FirstOrDefault();
            if (ex != null)
            {
                ex.Ex_active = '1'; //activate
            }
            try
            {
                db.SubmitChanges(); 
                return Ok(true);
            }
            catch (InvalidDataContractException exerption)
            {
                exerption.GetBaseException();

                return Ok(false);
            }

        }
        
        [Route("api/Exercise/DeActivateExercise")]
        [HttpGet]
        public IHttpActionResult DeActivateExercise(int exerciseid)
        {
            var ex = (from a in db.Exercises
                      where a.Ex_id.Equals(exerciseid)
                      select a).FirstOrDefault();
            if (ex != null)
            {
                ex.Ex_active = '0'; //deactivate
            }
            try
            {
                db.SubmitChanges(); 
                return Ok(true);
            }
            catch (InvalidDataContractException exerption)
            {
                exerption.GetBaseException();

                return Ok(false);
            }
        }
        

        [Route("api/Exercise/EditExercise")]
        [HttpPost]
        public IHttpActionResult EditExercise(ExerciseClass exerciseClass)
        {

            if (exerciseClass==null) {
                return Ok(false);
            }
            var exercise = (from e in db.Exercises
                            where e.Ex_id.Equals(exerciseClass.Ex_id)
                            select e).FirstOrDefault();

            exercise.Ex_name = exerciseClass.Name.Trim();
            exercise.EX_description = exerciseClass.description.Trim();
            exercise.mediaPath = exerciseClass.mediaPath;
            //edit status & active

            try
            {
                db.SubmitChanges(); //does not want to update
                return Ok(true);
            }
            catch (InvalidDataContractException ex)
            {
                ex.GetBaseException();

                return Ok(false);
            }

        }

        [Route("api/Exercise/GetExercise")]
        [HttpGet]
        public IHttpActionResult GetExercise(int exerciseid)
        {
            var addEx = (from ex in db.Exercises
                             where ex.Ex_id.Equals(exerciseid)
                             select ex).FirstOrDefault();
            ExerciseClass exerciseClass = new ExerciseClass { Ex_id=addEx.Ex_id,Name=addEx.Ex_name,description=addEx.EX_description,mediaPath=addEx.mediaPath,isActive=Convert.ToChar( addEx.Ex_active )};
            return Ok(exerciseClass);
        }


        [Route("api/Exercise/GetExercises")]
        [HttpGet]
        public IHttpActionResult GetExercises()
        {
            List<ExerciseClass> listExercises = new List<ExerciseClass>();

            var ex = (from e in db.Exercises

                      select e);
            if (ex==null) {
                return Ok(false);
            }
            foreach (Exercise e in ex)
            {
                ExerciseClass exerciseClass = new ExerciseClass { Ex_id = e.Ex_id, Name = e.Ex_name, description = e.EX_description, mediaPath = e.mediaPath, isActive = Convert.ToChar(e.Ex_active) };

                listExercises.Add(exerciseClass);
            }
            return Ok(listExercises);
        }

        [Route("api/Exercise/addExercise")]
        [HttpPost]
        public IHttpActionResult addExercise(ExerciseClass exercise)
        {
            if (exercise==null) {
                return Ok(false);
            }
            var newExercise = new Exercise
            {
                Ex_id = exercise.Ex_id,
                Ex_name = exercise.Name,
                mediaPath=exercise.mediaPath,
                EX_description = exercise.description,
                Ex_active = exercise.isActive,

            };
            db.Exercises.InsertOnSubmit(newExercise);

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException e)
            {
                e.GetBaseException();
                return Ok(false);
            }


        }

        [Route("api/Exercise/prescribeExercise")]
        [HttpPost]
        public IHttpActionResult prescribeExercise(PrescribeExerciseClass prescribeExercise)
        {
            //prescribe new Exercise
            var isprescribed = (from a in db.Prescribe_Exercises
                                  where a.Student_Num.Equals(prescribeExercise.Student_Num)
                                  && a.Couns_id.Equals(prescribeExercise.Couns_id)
                                  && a.Ex_id.Equals(prescribeExercise.Ex_id)
                                  && a.isprescribed.Equals(1)
                                  select a).FirstOrDefault();
            if (isprescribed!=null)
            {
                //if the exercise is prescribed the Counsellor should not be allowed to prescribed the same exercise(duplicate prescription)
                return Ok("Duplicate");
            }
            //if (onceprescribed != null)
            //{
                //if the exercise was once prescribed, then update
                //onceprescribed.IsLatestCompleted = 0;
                //onceprescribed.isprescribed = 1;


            //}
            //else
            //{
                var prescribe = new Prescribe_Exercise
                {
                    Couns_id = prescribeExercise.Couns_id,
                    Student_Num = prescribeExercise.Student_Num,
                    Ex_id = prescribeExercise.Ex_id,
                    Date_prescribed =Convert.ToDateTime(prescribeExercise.DatePrescribed),
                    IsLatestCompleted = 0,
                    num_completion = 0,
                    isprescribed = 1 //1-> prescribed and 0->not prescribed

                };
                db.Prescribe_Exercises.InsertOnSubmit(prescribe);
            //}


            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException e)
            {
                e.GetBaseException();
                return Ok(false);
            }

        }

        [Route("api/Exercise/UnPrescribeExercise")]
        [HttpPost]
        public IHttpActionResult UnPrescribeExercise(PrescribeExerciseClass prescribeExercise)
        {
            //Unprescribe Exercise
            var onceprescribed = (from a in db.Prescribe_Exercises
                                  where a.Student_Num.Equals(prescribeExercise.Student_Num)
                                  && a.Couns_id.Equals(prescribeExercise.Couns_id)
                                  && a.Ex_id.Equals(prescribeExercise.Ex_id)
                                  && a.isprescribed.Equals(1)
                                  select a).FirstOrDefault();
            if (onceprescribed == null)
            {
                return Ok(false);
                
            }
            //if the exercise was once prescribed, then update
            onceprescribed.isprescribed = 0; //not prescribed

            try
            {
                db.SubmitChanges();
                return Ok(true);
            }
            catch (InvalidDataContractException e)
            {
                e.GetBaseException();
                return Ok(false);
            }
        }

        [Route("api/Exercise/exerciseCompleted")]
        [HttpPost]
        public IHttpActionResult exerciseCompleted(PrescribeExerciseClass prescribeExercise)
        {
            //prescribe new Exercise
            var onceprescribed = (from a in db.Prescribe_Exercises
                                  where a.Student_Num.Equals(prescribeExercise.Student_Num)
                                  && a.Couns_id.Equals(prescribeExercise.Couns_id)
                                  && a.Ex_id.Equals(prescribeExercise.Ex_id)
                                  && a.IsLatestCompleted.Equals(0) //making sure that it does not take the 1st duplicate exercise that has already been complited
                                  select a).FirstOrDefault();
            if (onceprescribed != null)
            {
                //if the exercise was once prescribed, then update
                onceprescribed.IsLatestCompleted = 1;
                onceprescribed.num_completion++;
                onceprescribed.isprescribed = 0; //not prescribed
                try
                {
                    db.SubmitChanges();
                    return Ok(true);
                }
                catch (InvalidDataContractException e)
                {
                    e.GetBaseException();
                    return Ok(false);
                }

            }
            else
            {
                return Ok(false);
            }



        }

        [Route("api/Exercise/getStudentPrescribedExercises")]
        [HttpGet]
        public IHttpActionResult getStudentPrescribedExercises(int studentNum)
        {

            var prescribed = (from a in db.Prescribe_Exercises
                              where a.Student_Num.Equals(studentNum)
                              select a);
            List<PrescribeExerciseClass> exercises = new List<PrescribeExerciseClass>();

            foreach (Prescribe_Exercise e in prescribed)
            {
                PrescribeExerciseClass exerciseClass = new PrescribeExerciseClass { ID=e.ID,Couns_id=e.Couns_id,Ex_id=e.Ex_id,Student_Num=Convert.ToInt32(e.Student_Num), DatePrescribed=Convert.ToDateTime(e.Date_prescribed),IsLatestCompleted=Convert.ToInt32(e.IsLatestCompleted),numCompletion=Convert.ToInt32(e.num_completion),isPrescribed=Convert.ToInt32( e.isprescribed) };

                exercises.Add(exerciseClass);
            }
            return Ok(exercises);

        }

        [Route("api/Exercise/getAllPrescribedExercises")]
        [HttpGet]
        public IHttpActionResult getAllPrescribedExercises()
        {
            //get all exercises once prescribed and completed
            var prescribed = (from a in db.Prescribe_Exercises
                              select a);
            List<PrescribeExerciseClass> exercises = new List<PrescribeExerciseClass>();

            foreach (Prescribe_Exercise e in prescribed)
            {
                PrescribeExerciseClass exerciseClass = new PrescribeExerciseClass { ID = e.ID, Couns_id = e.Couns_id, Ex_id = e.Ex_id, Student_Num = Convert.ToInt32(e.Student_Num), DatePrescribed = Convert.ToDateTime(e.Date_prescribed), IsLatestCompleted = Convert.ToInt32(e.IsLatestCompleted), numCompletion = Convert.ToInt32(e.num_completion), isPrescribed = Convert.ToInt32(e.isprescribed) };

                exercises.Add(exerciseClass);
            }
            return Ok(exercises);

        }

    }
}
